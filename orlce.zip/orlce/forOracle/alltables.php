<!DOCTYPE html>
<html>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="../css/main.css">
  <link rel="stylesheet" href="../css/table.css">
  <title>SSS</title>
</head>
<body>
  <div class="shp">
    <ul id="navbar">
          <a href="#" style="padding: 6px; width: 300px; color: #000000; float: left; text-decoration: none; text-align: center;">Selling Sites Site</a>
          <li><a href="#">Базы</a>
            <ul>
              <li><a href="#">БД 1</a></li>
              <li><a href="#">БД 2</a></li>
              <li><a href="#">БД 3</a></li>
              <li><a href="#">БД 4</a></li>
            </ul>
          </li>
          <li><a href="../main.php">Главная</a></li>
        </ul>
  </div>
<div>
  <h1 style="padding-left : 5px">Таблицы:</h1>

  <div class="cardsbd">
    <div class="card">
      <div class="container">
        <div class="txtbtn">
          <div class="txt"><h3><b>Клиенты</b></h3></div>
          <a href="checkTable.php?tbname=clients"><div class="btn"><button type="button" class="button1">check</button></a></div>
        </div>
      </div>
    </div>
  </div>

  <br>

  <div class="cardsbd">
    <div class="card">
      <div class="container">
        <div class="txtbtn">
          <div class="txt"><h3><b>Заказы</b></h3></div>
          <a href="checkTable.php?tbname=ordering_websites"><div class="btn"><button type="button" class="button1">check</button></a></div>
        </div>
      </div>
    </div>
  </div>

  <br>

  <div class="cardsbd">
    <div class="card">
      <div class="container">
        <div class="txtbtn">
          <div class="txt"><h3><b>Пожелания</b></h3></div>
          <a href="checkTable.php?tbname=suggestions"><div class="btn"><button type="button" class="button1">check</button></a></div>
        </div>
      </div>
    </div>
  </div>

  <br>

  <div class="cardsbd">
    <div class="card">
      <div class="container">
        <div class="txtbtn">
          <div class="txt"><h3><b>Сервисы</b></h3></div>
          <a href="checkTable.php?tbname=services"><div class="btn"><button type="button" class="button1">check</button></a></div>
        </div>
      </div>
    </div>
  </div>

  <br>

  <div class="cardsbd">
    <div class="card">
      <div class="container">
        <div class="txtbtn">
          <div class="txt"><h3><b>Сайты к сервисам</b></h3></div>
          <a href="checkTable.php?tbname=websitestoservices"><div class="btn"><button type="button" class="button1">check</button></a></div>
        </div>
      </div>
    </div>
  </div>

  <br>

  <div class="cardsbd">
    <div class="card">
      <div class="container">
        <div class="txtbtn">
          <div class="txt"><h3><b>Дизайн проекты</b></h3></div>
          <a href="checkTable.php?tbname=design_project"><div class="btn"><button type="button" class="button1">check</button></a></div>
        </div>
      </div>
    </div>
  </div>

  <br>

  <div class="cardsbd">
    <div class="card">
      <div class="container">
        <div class="txtbtn">
          <div class="txt"><h3><b>Сайты к дизайн проектам</b></h3></div>
          <a href="checkTable.php?tbname=websitestodesign"><div class="btn"><button type="button" class="button1">check</button></a></div>
        </div>
      </div>
    </div>
  </div>

  <br>

  <div class="cardsbd">
    <div class="card">
      <div class="container">
        <div class="txtbtn">
          <div class="txt"><h3><b>Элементы сайты</b></h3></div>
          <a href="checkTable.php?tbname=site_elements"><div class="btn"><button type="button" class="button1">check</button></a></div>
        </div>
      </div>
    </div>
  </div>

  <br>

  <div class="cardsbd">
    <div class="card">
      <div class="container">
        <div class="txtbtn">
          <div class="txt"><h3><b>Сайты к элементам</b></h3></div>
          <a href="checkTable.php?tbname=websitestoelements"><div class="btn"><button type="button" class="button1">check</button></a></div>
        </div>
      </div>
    </div>
  </div>

  <br>

</div>
</body>
</html>
