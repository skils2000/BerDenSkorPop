<?php
global $conn;
$conn = oci_connect('SYS', 'QwErTy', 'orcle', null, OCI_SYSDBA);

?>
