﻿<!DOCTYPE html>
<html>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="../css/main.css">
  <link rel="stylesheet" href="../css/table.css">
  <title>Site</title>
</head>
<body>
<div>
  <h1 style="padding-left : 5px">Site - таблицы:</h1>
        <?php
        //This path should point to Composer's autoloader from where your MongoDB library will be loaded
          require '../vendor/autoload.php';
          // when using default settings
            try {
                  $mongo = new MongoDB\Client('mongodb://localhost:27017');
            } catch (Exception $e) {
                  echo $e->getMessage();
            }
            $db = $mongo->Site;
            foreach ($db->listCollections() as $item) {
              echo "<div class=\"cardsbd\">
                  <div class=\"card\">
                    <div class=\"container\">";
              echo "<div class=\"txtbtn\">";
              echo "<div class=\"txt\"><h3><b>" . $item['name'] . "</b></h3></div>";
              echo "<a href=\"table.php?tbname=" . $item['name'] . "\"><div class=\"btn\"><button type=\"button\" class=\"button1\">check</button></a></div>";
			  //echo "<a href=\".php?tbname=" . $item['name'] . "\"><div class=\"btn\"><button type=\"button\" class=\"button1\">Zapros</button></a></div>";
              echo "</div>";
              echo "</div>
                  </div>
                </div>";
              echo "<br>";
            }
         ?>
</div>
</body>
</html>
