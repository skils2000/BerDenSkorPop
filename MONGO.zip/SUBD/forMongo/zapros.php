<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="../css/main.css">
  <link rel="stylesheet" href="../css/table.css">
  <title>Site</title>
</head>
  <body>
    <?php $cur_tb = $_GET['tbname'];
    echo "<form action=\"funcQuery.php?tbname=" . $cur_tb . "\" method=\"post\">"; ?>
     <h5>Введите ценовой диапазон</h5>
     <p>Min: <input type="text" name="minlat"></p>
     <p>Max: <input type="text" name="maxlat"></p>
     <p><input type="submit" value="Отправить"></p>
    </form>
  </body>
</html>
