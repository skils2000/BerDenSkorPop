﻿<!DOCTYPE html>
<html>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="css/main.css">
  <title>Site</title>
</head>
<body>
  
<div>
  <h1 style="padding-left : 5px">Базы данных</h1>
  <div class="cardsbd">
    <div class="card">
      <div class="container">
        <h3><b>Oracle</b></h3>
        <p>Основа</p>
      </div>
    </div>
    <br>
    <!--  -->
    <div class="card">
      <div class="container">
        <h3><b>MSSQL</b></h3>
        <p>Резерв 1</p>
      </div>
    </div>
    <br>
    <!--  -->
    <div class="card">
      <div class="container">
        <h3><a href="forMongo/bd.php">Mongo</a></b></h3>
        <p>Резерв 2</p>
      </div>
    </div>
	<!--  -->
	<br>
    <!--  -->
    <div class="card">
      <div class="container">
        <h3><b>PSTG</b></h3>
        <p>Резерв 3</p>
      </div>
    </div>
    <br>
    </div>
  </div>
</div>
</body>
</html>
