<html>
<head>
<h1>Процент товаров цена которых <= 100000</h1>
</head>
<a href="_Design_project.php" ><button type="button" > Назад</button></a>
<h1></h1>
</body>

<?php
	ini_set('display_errors', 1);
	error_reporting(~0);

   $serverName = "localhost";
   $userName = "1234";
   $userPassword = "1234";
   $dbName = "berdenscorpop";
  
   $connectionInfo = array("Database"=>$dbName, "UID"=>$userName, "PWD"=>$userPassword, "MultipleActiveResultSets"=>true, "CharacterSet" => "UTF-8");
   $id = isset($_GET['id']) ? (int)$_GET['id'] : false;
   
   $conn = sqlsrv_connect( $serverName, $connectionInfo);

	if( $conn === false ) {
		die( print_r( sqlsrv_errors(), true));
	}

   $stmt = "SELECT COUNT(*)*100 /(SELECT COUNT(*) FROM Design_project)as count FROM Design_project WHERE price <=100000";
   $query = sqlsrv_query($conn, $stmt);

?>
<table width="250" border="1">
  <tr>
    <th width="41"> <div align="center">%</div></th>
  </tr>
<?php
while($result = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC))
{
?>
  <tr>
    <td><div align="center"><?php echo $result["count"];?></div></td>
  </tr>
<?php
}
?>
</table>

<?php
sqlsrv_close($conn);
?>

</html>