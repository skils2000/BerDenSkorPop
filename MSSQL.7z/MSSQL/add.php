<html>
<head>
<title>ThaiCreate.Com PHP & SQL Server (sqlsrv)</title>
</head>
<body>
<form action="save_add.php" name="frmAdd" method="post">
<table width="284" border="1">
  <tr>
    <th width="120">ФИО</th>
    <td><input type="text" name="txtFIO" size="20"></td>
    </tr>
  <tr>
    <th width="120">Телефон</th>
    <td><input type="text" name="txtContacts" size="20"></td>
    </tr>
  </table>
  <input type="submit" name="submit" value="Подтвердить">
</form>
</body>
</html>