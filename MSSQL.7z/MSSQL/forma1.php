<html>
<head>
<title>ThaiCreate.Com PHP & SQL Server (sqlsrv)</title>
</head>
<body>
<form action="zapros1.php" name="frmAdd" method="post">
<table width="284" border="1">
  <tr>
    <th width="120">Буква</th>
    <td><input type="text" name="txtBukva" size="20"></td>
    </tr>
  </table>
  <h1></h1>
  <input type="submit" name="submit" value="Подтвердить">
</form>
</body>
</html>