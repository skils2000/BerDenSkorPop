<html>
<head>
<h1>Client</h1>
</head>
<a href="main.php" ><button type="button" > Назад</button></a>
</body>

</body>
<head>
<h1></h1>
</head>
</body>

</body>
<head>
<h1></h1>
</head>

<a href="add.php" ><button type="button" > + Добавить</button></a>

<a href="zapros1.php" ><button type="button" > Запрос</button></a>
<head>
<h1></h1>
</head>
<body>
<?php
	ini_set('display_errors', 1);
	error_reporting(~0);

   $serverName = "localhost";
   $userName = "1234";
   $userPassword = "1234";
   $dbName = "berdenscorpop";
  
   $connectionInfo = array("Database"=>$dbName, "UID"=>$userName, "PWD"=>$userPassword, "MultipleActiveResultSets"=>true, "CharacterSet" => "UTF-8");
   $id = isset($_GET['id']) ? (int)$_GET['id'] : false;
   
   $conn = sqlsrv_connect( $serverName, $connectionInfo);

	if( $conn === false ) {
		die( print_r( sqlsrv_errors(), true));
	}

   $stmt = "SELECT * FROM Client";
   $query = sqlsrv_query($conn, $stmt);

?>
<table width="850" border="1">
  <tr>
    <th width="41"> <div align="center">№ </div></th>
    <th width="150"> <div align="center">Ф.И.О. </div></th>
    <th width="138"> <div align="center">Телефон </div></th>
	<th width="80"> <div align="center"></div></th>
	<th width="60"> <div align="center"></div></th>
  </tr>
<?php
while($result = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC))
{
?>
  <tr>
    <td><div align="center"><?php echo $result["id"];?></div></td>
    <td><?php echo $result["FIO"];?></td>
    <td><?php echo $result["Contacts"];?></td>
	<td align="center"><a href="JavaScript:if(confirm('Вы точно хотите УДАЛИТЬ эту строку?')==true){window.location='delete.php?id=<?php echo $result["id"];?>';}">Удалить</a></td>
    <td align="center"><a href="edit.php?id=<?php echo $result["id"];?>">Изменить</a></td>
  </tr>
<?php
}
?>
</table>

<?php
sqlsrv_close($conn);
?>

</html>
