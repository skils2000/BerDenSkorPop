<html>
<head>
<title>ThaiCreate.Com PHP & SQL Server (sqlsrv)</title>
</head>
<body>
<form action="save_add2.php" name="frmAdd" method="post">
<table width="284" border="1">
  <tr>
    <th width="120">Название</th>
    <td><input type="text" name="txtname" size="20"></td>
    </tr>
  <tr>
    <th width="120">Описание</th>
    <td><input type="text" name="txtDescription" size="20"></td>
    </tr>
   <tr>
    <th width="120">Цена /руб.</th>
    <td><input type="text" name="txtPrice" size="20"></td>
    </tr>
  </table>
  <input type="submit" name="submit" value="Подтвердить">
</form>
</body>
</html>