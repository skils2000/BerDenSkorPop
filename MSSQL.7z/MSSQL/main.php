<html>
<head>
<title> PHP & SQL Server (sqlsrv)</title>
<h1>ТАБЛИЦЫ</h1>
</head>
<body>
<?php
	ini_set('display_errors', 1);
	error_reporting(~0);

   $serverName = "localhost";
   $userName = "1234";
   $userPassword = "1234";
   $dbName = "berdenscorpop";
  
   $connectionInfo = array("Database"=>$dbName, "UID"=>$userName, "PWD"=>$userPassword, "MultipleActiveResultSets"=>true, "CharacterSet" => "UTF-8");
   $id = isset($_GET['id']) ? (int)$_GET['id'] : false;
   
   $conn = sqlsrv_connect( $serverName, $connectionInfo);
   if( $conn === false ) {
		die( print_r( sqlsrv_errors(), true));
	}
	
	?>
	<head>
<h1></h1>
</head>
<a href="_Client.php" ><button type="button" > Client</button></a>

<head>
<h1></h1>
</head>
<a href="_Design_project.php" ><button type="button" > Design_project</button></a>



<head>
<h1></h1>
</head>
<a href="_Services.php" ><button type="button" > Services</button></a>

<head>
<h1></h1>
</head>
<a href="_Site Elements.php" ><button type="button" > Site Elements</button></a>

<head>
<h1></h1>
</head>
<a href="_Suggestions.php" ><button type="button" > Suggestions</button></a>

<head>
<h1></h1>
</head>
<a href="_Ordering_website.php" ><button type="button" > Ordering_website</button></a>

</html>
