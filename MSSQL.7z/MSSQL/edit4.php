<html>
<head>
<title> PHP & SQL Server (sqlsrv)</title>
</head>
<body>
<?php
   ini_set('display_errors', 1);
   error_reporting(~0);

   $serverName = "localhost";
   $userName = "1234";
   $userPassword = "1234";
   $dbName = "berdenscorpop";

   $strid = null;

   if(isset($_GET["id"]))
   {
	   $strid = $_GET["id"];
   }
  
   $connectionInfo = array("Database"=>$dbName, "UID"=>$userName, "PWD"=>$userPassword, "MultipleActiveResultSets"=>true, "CharacterSet" => "UTF-8");

   $conn = sqlsrv_connect( $serverName, $connectionInfo);

   if( $conn === false ) {
      die( print_r( sqlsrv_errors(), true));
   }

	$stmt = "SELECT * FROM Services WHERE id = ? ";
	$params = array($strid);

	$query = sqlsrv_query( $conn, $stmt, $params);

	$result = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC);

?>
<form action="save4.php" name="frmAdd" method="post">
<table width="284" border="1">
  <tr>
    <th width="120">№</th>
    <td width="238"><input type="hidden" name="txtid" value="<?php echo $result["id"];?>"><?php echo $result["id"];?></td>
    </tr>
  <tr>
    <th width="120">Название</th>
    <td><input type="text" name="txtname" size="20" value="<?php echo $result["Name"];?>"></td>
    </tr>
	<tr>
    <th width="120">Цена /руб.</th>
    <td><input type="text" name="txtPrice" size="20" value="<?php echo $result["Price"];?>"></td>
    </tr>
  </table>
  <input type="submit" name="submit" value="Подтвердить">
</form>
<?php
sqlsrv_close($conn);
?>
</body>
</html>