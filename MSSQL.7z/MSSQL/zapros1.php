<html>
<head>
<h1>Количество человек начинающихся с буквы В</h1>
</head>
<a href="_Client.php" ><button type="button" > Назад</button></a>
<h1></h1>
</body>

<?php
	ini_set('display_errors', 1);
	error_reporting(~0);

   $serverName = "localhost";
   $userName = "1234";
   $userPassword = "1234";
   $dbName = "berdenscorpop";
  
   $connectionInfo = array("Database"=>$dbName, "UID"=>$userName, "PWD"=>$userPassword, "MultipleActiveResultSets"=>true, "CharacterSet" => "UTF-8");
   $id = isset($_GET['id']) ? (int)$_GET['id'] : false;
   
   $conn = sqlsrv_connect( $serverName, $connectionInfo);

	if( $conn === false ) {
		die( print_r( sqlsrv_errors(), true));
	}

   $stmt = "SELECT COUNT(*) as count FROM Client WHERE FIO like 'В%'";
   $query = sqlsrv_query($conn, $stmt);

?>
<table width="250" border="1">
  <tr>
    <th width="41"> <div align="center">Количество</div></th>
  </tr>
<?php
while($result = sqlsrv_fetch_array($query, SQLSRV_FETCH_ASSOC))
{
?>
  <tr>
    <td><div align="center"><?php echo $result["count"];?></div></td>
  </tr>
<?php
}
?>
</table>

<?php
sqlsrv_close($conn);
?>

</html>
